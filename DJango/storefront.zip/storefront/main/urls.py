from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path("end/", views.end, name="end"), # /end/
    path("inbound/", views.inbound, name="inbound"), # /inbound/
    path("outbound/", views.outbound, name="outbound"), # /outbound/
    path("item/", views.item, name="item"), # /item/
]