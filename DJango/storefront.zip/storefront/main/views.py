from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def end(response):
    return HttpResponse("<h1>End World</h1>")

def home(request):
    return render(request, "main/home.html")

def inbound(request):
    return render(request, "main/inbound.html")

def outbound(response):
    return HttpResponse("<h1>Outbound World</h1>")

def item(response):
    return HttpResponse("<h1>Item World</h1>")
